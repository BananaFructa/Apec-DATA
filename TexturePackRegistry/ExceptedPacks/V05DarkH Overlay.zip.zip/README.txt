Aaa YEs Hello This is read me file
Thank you for downloading Very Very cool resoruce pack that has cool stuff for hypixel which i will not be listing
Anyways here are some basic stuff you agree to upon downloading the pack
Beta versions of this pack will be sent in Priority pack releases for priority users
for more information on priority see the #info and rules channel in the discord or the google document
ENJOY THE PACK OR ELSE I WATER GUN UR PC :gun:

You cannot send modified versions of this pack
You cannot send any version of this pack to anyone unless a staff member of the discord tells you otherwise
Do not distribute the copys in a other server or social media that is not the discord server it was posted in originalyl (DarkCheese's packs discord)
respect the pack like it was your own (this means Dont hate on the pack for no reason without trying it or just hating on it overall cuz you wouldnt like taht happening to ur pack would you?)
You agree that in any scenario a staff member can ban you from the server whether you broke the rules or not.

If you are caught breaking any of the guidelines you will be instantly banned from the discord server without hesitation
and anyone who has downloaded the distributed copy will also be banned. 
Also i will rip out every bone you have on you untill i am satisfied if you fail to comply to the guidelines

also here have a donut
                                                             
                                                                               
                                           $$@@@@@@                            
                                      #########$$$$@@@@$                       
                                  ###*!!!==!!!**##$$$@@@$$                     
                                ##**=!==;=;:;=!!**#$$$$$$$$#                   
                              *#**!!=;::~~~~~:==**##$$$$$$$##                  
                             ###*!!=:~-,...,-~;=!*###$$$$$$##*                 
                            #####!=:~,......,~;=!*###$$$$$$##*=                
                           #$$$##*!;~-....  .:=!**###$$$$####*!                
                          *$$$$$##!;~..     :=!**###########**=                
                         =#$$@@$$#*=~.     ;!!**###########**!=                
                         !#$@@@@$$#*;    =!****#########*#**!!;                
                         !#$$$@@$$$#*!!!****###########****!!=~                
                         =*#$$$$$$$#################******!=;;                 
                         ;!*##$$$################******!!!!=;                  
                         :;!**###########*#*******!!!*!!==;:-                  
                          :;=!!****************!!!!!!===;:~                    
                           :;===!!!!!!!!!!!!!!!!!!===;;:~-                     
                            ~:;=;!!=!=!!!!!!====;=;;::~-                       
                              -~::;;==;;=;;=;;;;::~~-.          